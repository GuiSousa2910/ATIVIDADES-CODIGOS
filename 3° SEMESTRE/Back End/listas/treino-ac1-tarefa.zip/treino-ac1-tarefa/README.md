### Enunciado da API REST - Gerenciamento de Tarefas

#### **Objetivo**
Criar uma API REST para gerenciar tarefas, garantindo que as tarefas com prazos vencidos sejam marcadas como atrasadas na resposta.

---

### **Modelo de Entidade**
A entidade **Tarefa** deve conter os seguintes atributos:

```json
{
  "id": 2,
  "titulo": "TAREFA A",
  "descricao": "descricao",
  "prazo": "2025-08-10T10:00:00",
  "status": "EM_DIA"
}
```
ou

```json
{
  "id": 3,
  "titulo": "TAREFA B",
  "descricao": "descricao",
  "prazo": "1999-06-10T10:00:00",
  "status": "ATRASADA"
}
```
ou
```json
{
  "id": 1,
  "titulo": "TESTE 10",
  "descricao": "descricao",
  "prazo": "2026-06-10T10:00:00",
  "status": "FINALIZADA",
  "finalizada": true
}
```

O status da tarefa é determinado com base no prazo e no estado de finalização.
Se a tarefa estiver marcada como finalizada, seu status será sempre "FINALIZADA", independentemente do prazo.

Caso a tarefa não esteja finalizada, o status dependerá da comparação entre a data atual e o prazo: se a data atual for anterior ao prazo, o status será "EM_DIA"; se a data atual for posterior ao prazo, o status será "ATRASADA".

---

### **Requisitos**

A classe da entidade **Tarefa** já possui uma implementação parcial. Complete-a para atender às regras descritas abaixo.

---

### **Endpoints**

#### **1. Listar todas as tarefas**
**GET** `/tarefas`
- Retorna a lista de tarefas cadastradas.
- Se não houver tarefas cadastradas, deve retornar o código HTTP adequado.

#### **2. Cadastrar uma nova tarefa**
**POST** `/tarefas`
- Adiciona uma nova tarefa e retorna a mesma com um ID gerado.
- A data da tarefa não pode estar no passado.
- O título da tarefa não pode se repetir, independentemente de letras maiúsculas ou minúsculas.
- Se um título já existir, o sistema deve retornar o código HTTP adequado.

#### **3. Buscar uma tarefa pelo ID**
**GET** `/tarefas/{id}`
- Retorna os detalhes da tarefa correspondente ao ID informado.
- Se a tarefa não for encontrada, retorna o código HTTP adequado.

#### **4. Atualizar uma tarefa existente**
**PUT** `/tarefas/{id}`
- Atualiza os dados de uma tarefa existente com base no ID informado.
- A data da tarefa não pode estar no passado.
- Se a tarefa não for encontrada, retorna o código HTTP adequado.
- Se o novo título já existir em outra tarefa, retorna o código HTTP adequado.

#### **5. Remover uma tarefa**
**DELETE** `/tarefas/{id}`
- Remove a tarefa com base no ID informado.
- Se a tarefa não for encontrada, retorna o código HTTP adequado.

#### **6. Listar tarefas atrasadas**
**GET** `/atrasadas`
- Retorna apenas as tarefas que estão atrasadas.
- Se não houver tarefas atrasadas, retorna o código HTTP adequado.

#### **7. Buscar tarefas dentro de um período**
**GET** `/periodo?inicio={data_inicial}&fim={data_final}`
- Retorna as tarefas que possuem prazo dentro do período especificado.
- Se não houver tarefas no período informado, retorna o código HTTP adequado.

---

A implementação deve seguir boas práticas de desenvolvimento, garantindo a integridade dos dados e o correto tratamento de erros.