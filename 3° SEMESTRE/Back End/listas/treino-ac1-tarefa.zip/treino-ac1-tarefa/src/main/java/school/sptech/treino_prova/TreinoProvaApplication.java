package school.sptech.treino_prova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TreinoProvaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TreinoProvaApplication.class, args);
	}
}
