package school.sptech.treino_prova.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.database.rider.core.api.dataset.DataSet;
import com.github.database.rider.core.api.dataset.ExpectedDataSet;
import com.github.database.rider.spring.api.DBRider;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import school.sptech.treino_prova.Tarefa;
import school.sptech.treino_prova.fixture.TarefaAtualizacaoFixture;

import java.time.LocalDateTime;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@DBRider
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@DisplayName("5. [Tarefa] Atualização")
public class TarefaAtualizacaoTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @ParameterizedTest
    @DataSet(value = "data/atualizacao/inicial.json", cleanBefore = true, cleanAfter = true)
    @MethodSource("school.sptech.treino_prova.fixture.TarefaAtualizacaoFixture#getTarefasParaAtualizar")
    @DisplayName("5.1. Quando atualizar tarefa com sucesso, então deve retornar tarefa com código HTTP correto [ LOTE ]")
    void quandoAtualizarTarefaComSucessoEntaoRetornarTarefaComStatusAdequado(Tarefa tarefa) throws Exception {
        mockMvc.perform(put("/tarefas/{id}", tarefa.getId())
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(tarefa.getId()))
                .andExpect(jsonPath("$.titulo").value(tarefa.getTitulo()))
                .andExpect(jsonPath("$.descricao").value(tarefa.getDescricao()))
                .andExpect(jsonPath("$.status").value("EM_DIA"));
    }

    @ParameterizedTest
    @MethodSource("school.sptech.treino_prova.fixture.TarefaAtualizacaoFixture#getTarefaParaAtualizacaoUnica")
    @DataSet(value = "data/atualizacao/inicial.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/atualizacao/final.json", ignoreCols = {" id", "prazo"})
    @DisplayName("5.2. Quando atualizar tarefa com sucesso, então deve retornar a tarefa e código HTTP correto [ ÚNICO - DB ]")
    void quandoAtualizarTarefaComSucessoEntaoRetornarStatusAdequado(Tarefa tarefa) throws Exception {

        mockMvc.perform(put("/tarefas/{id}", tarefa.getId())
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(tarefa.getId()))
                .andExpect(jsonPath("$.titulo").value(tarefa.getTitulo()))
                .andExpect(jsonPath("$.descricao").value(tarefa.getDescricao()))
                .andExpect(jsonPath("$.status").value("EM_DIA"));
    }

    @ParameterizedTest
    @MethodSource("school.sptech.treino_prova.fixture.TarefaAtualizacaoFixture#getTarefaParaAtualizacaoUnica")
    @DataSet(value = "data/atualizacao/inicial.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/atualizacao/final.json", ignoreCols = {"id", "prazo"})
    @DisplayName("5.3. Não deve considerar o ID no corpo da requisição [ ÚNICO - DB ]")
    void naoDeveConsiderarIdNoCorpoDaRequisicao(Tarefa tarefa) throws Exception {

        final var idCorreto = tarefa.getId();

        tarefa.setId(23);

        mockMvc.perform(put("/tarefas/{id}", idCorreto)
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(idCorreto))
                .andExpect(jsonPath("$.titulo").value(tarefa.getTitulo()))
                .andExpect(jsonPath("$.descricao").value(tarefa.getDescricao()))
                .andExpect(jsonPath("$.status").value("EM_DIA"));
    }

    @ParameterizedTest
    @MethodSource("school.sptech.treino_prova.fixture.TarefaAtualizacaoFixture#getTarefasParaAtualizarInvalidas")
    @DataSet(value = "data/atualizacao/inicial.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/atualizacao/inicial.json", ignoreCols = {"id", "prazo"})
    @DisplayName("5.4. Quando atualizar tarefa com ID inexistente, então deve retornar código HTTP correto [ LOTE ]")
    void quandoAtualizarTarefaComIdInexistenteEntaoRetornarStatusAdequado(Tarefa tarefa) throws Exception {
        mockMvc.perform(put("/tarefas/{id}", tarefa.getId())
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isNotFound());
    }

    @ParameterizedTest
    @MethodSource("school.sptech.treino_prova.fixture.TarefaAtualizacaoFixture#getTarefaParaAtualizacaoComNomeInvalidoUnica")
    @DataSet(value = "data/atualizacao/inicial.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/atualizacao/inicial.json", ignoreCols = {"id", "prazo"})
    @DisplayName("5.5. Quando atualizar tarefa com título já existente em outro ID, deve impedir e então retornar status HTTP correto [ ÚNICO - DB ]")
    void quandoAtualizarTarefaComTituloJaExistenteEntaoRetornarStatusAdequado(Tarefa tarefa) throws Exception {
        mockMvc.perform(put("/tarefas/{id}", tarefa.getId())
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isConflict());
    }

    @ParameterizedTest
    @MethodSource("school.sptech.treino_prova.fixture.TarefaAtualizacaoFixture#getTarefaParaAtualizacaoComNomeInvalidoCaseInsensitiveUnica")
    @DataSet(value = "data/atualizacao/inicial.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/atualizacao/inicial.json", ignoreCols = {"id", "prazo"})
    @DisplayName("5.5. Quando atualizar tarefa com título já existente em outro ID (case insensitive), deve impedir e então retornar status HTTP correto [ ÚNICO - DB ]")
    void quandoAtualizarTarefaComTituloJaExistenteCaseInsensitiveEntaoRetornarStatusAdequado(Tarefa tarefa) throws Exception {
        mockMvc.perform(put("/tarefas/{id}", tarefa.getId())
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isConflict());
    }

    @ParameterizedTest
    @MethodSource("school.sptech.treino_prova.fixture.TarefaAtualizacaoFixture#getTarefaParaAtualizacaoDataInvalida")
    @DataSet(value = "data/atualizacao/inicial.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/atualizacao/inicial.json", ignoreCols = {"id", "prazo"})
    @DisplayName("5.6. Quando atualizar tarefa com prazo inválido, deve impedir e então retornar status HTTP adequado [ ÚNICO - DB ]")
    void quandoAtualizarTarefaComPrazoInvalidoEntaoRetornarStatusAdequado(Tarefa tarefa) throws Exception {
        mockMvc.perform(put("/tarefas/{id}", tarefa.getId())
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DataSet(value = "data/atualizacao/inicial-2.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/atualizacao/final-2.json", ignoreCols = {"id", "prazo"})
    @DisplayName("5.7. Quando atualizar com nome 'parcialmente igual' a outro registro, então DEVE atualizar o título [ ÚNICO - DB ]")
    void quandoAtualizarTarefaComNomeParcialmenteIgualEntaoDeveAtualizarOTitulo() throws Exception {

        int id = 24;

        Object tarefa = TarefaAtualizacaoFixture.criarTarefa(
                id,
                "Passar um dia",
                "Apenas curta o dia sem fazer nada. Às vezes, a melhor tarefa é não ter tarefa nenhuma.",
                LocalDateTime.now().plusDays(21).toString()
        );

        mockMvc.perform(put("/tarefas/{id}", id)
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(id))
                .andExpect(jsonPath("$.titulo").value("Passar um dia"))
                .andExpect(jsonPath("$.descricao").value("Apenas curta o dia sem fazer nada. Às vezes, a melhor tarefa é não ter tarefa nenhuma."))
                .andExpect(jsonPath("$.status").value("EM_DIA"));
    }

    @Test
    @DataSet(value = "data/atualizacao/inicial-3.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/atualizacao/final-3.json", ignoreCols = {"id", "prazo"})
    @DisplayName("5.7. Quando atualizar tarefa MANTENDO O NOME ANTERIOR, então DEVE atualizar e não gerar conflito [ ÚNICO - DB ]")
    void quandoAtualizarTarefaMantendoONomeAnteriorEntaoDeveAtualizarEManterSemConflito() throws Exception {

        int id = 15;

        Object tarefa = TarefaAtualizacaoFixture.criarTarefa(
                id,
                "Sair de casa sem fone de ouvido",
                "A sociedade pode ser barulhenta, mas quem sabe você descobre um novo som: o mundo real.",
                LocalDateTime.now().plusHours(12).toString()
        );

        mockMvc.perform(put("/tarefas/{id}", id)
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(id))
                .andExpect(jsonPath("$.titulo").value("Sair de casa sem fone de ouvido"))
                .andExpect(jsonPath("$.descricao").value("A sociedade pode ser barulhenta, mas quem sabe você descobre um novo som: o mundo real."))
                .andExpect(jsonPath("$.status").value("EM_DIA"));
    }
}
