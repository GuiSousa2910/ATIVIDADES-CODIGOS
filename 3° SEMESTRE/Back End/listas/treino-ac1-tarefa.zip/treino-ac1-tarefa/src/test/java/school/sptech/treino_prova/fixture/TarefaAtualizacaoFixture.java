package school.sptech.treino_prova.fixture;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.List;

import static school.sptech.treino_prova.fixture.Util.gerarDataFuturaAleatoria;
import static school.sptech.treino_prova.fixture.Util.gerarDataPassadaAleatoria;

public class TarefaAtualizacaoFixture {

    public static List<Object> getTarefaParaAtualizacaoUnica() {
        return List.of(
                criarTarefa(19, "FUI ATUALIZADO", "Será que deu certo?", gerarDataFuturaAleatoria())
        );
    }

    public static List<Object> getTarefaParaAtualizacaoComNomeInvalidoUnica() {
        return List.of(
                criarTarefa(19, "Abrir um e-mail sem surtar", "Será que deu certo?", gerarDataFuturaAleatoria())
        );
    }

    public static List<Object> getTarefaParaAtualizacaoComNomeInvalidoCaseInsensitiveUnica() {
        return List.of(
                criarTarefa(19, "AbriR um E-mail sem surtAr", "Será que deu certo?", gerarDataFuturaAleatoria())
        );
    }

    public static List<Object> getTarefaParaAtualizacaoDataInvalida() {
        return List.of(
                criarTarefa(1, "Atualizado - Maratona de 30 segundos", "Agora assista 20 vídeos inteiros no TikTok sem rolar para cima.", gerarDataPassadaAleatoria()),
                criarTarefa(2, "Atualizado - Ler um texto de mais de 3 linhas", "Leia um artigo inteiro sem resumir apenas no título.", gerarDataPassadaAleatoria()),
                criarTarefa(3, "Atualizado - Responder mensagem no mesmo dia", "Responda as mensagens em menos de 1 hora.", gerarDataPassadaAleatoria()),
                criarTarefa(4, "Atualizado - Sobreviver sem Wi-Fi", "Agora tente 30 minutos sem Wi-Fi ou 4G.", gerarDataPassadaAleatoria()),
                criarTarefa(5, "Atualizado - Usar um despertador de verdade", "Acorde sem apertar o botão de soneca.", gerarDataPassadaAleatoria()),
                criarTarefa(6, "Atualizado - Olhar para um livro sem surtar", "Leia 5 páginas de um livro e resista à tentação de pegar o celular.", gerarDataPassadaAleatoria()),
                criarTarefa(7, "Atualizado - Fazer uma refeição sem foto", "Coma sem tirar foto da comida e aproveite o momento.", gerarDataPassadaAleatoria()),
                criarTarefa(8, "Atualizado - Falar com alguém pessoalmente", "Converse cara a cara sem usar emojis ou figurinhas.", gerarDataPassadaAleatoria()),
                criarTarefa(9, "Atualizado - Usar menos de 50 filtros", "Poste uma foto natural, sem edição extrema.", gerarDataPassadaAleatoria()),
                criarTarefa(10, "Atualizado - Passar um dia sem falar 'cringe'", "Fique 24 horas sem usar a palavra 'cringe'.", gerarDataPassadaAleatoria())
        );
    }

    public static List<Object> getTarefasParaAtualizar() {
        return List.of(
                criarTarefa(1, "Atualizado - Maratona de 30 segundos", "Agora assista 20 vídeos inteiros no TikTok sem rolar para cima.", gerarDataFuturaAleatoria()),
                criarTarefa(2, "Atualizado - Ler um texto de mais de 3 linhas", "Leia um artigo inteiro sem resumir apenas no título.", gerarDataFuturaAleatoria()),
                criarTarefa(3, "Atualizado - Responder mensagem no mesmo dia", "Responda as mensagens em menos de 1 hora.", gerarDataFuturaAleatoria()),
                criarTarefa(4, "Atualizado - Sobreviver sem Wi-Fi", "Agora tente 30 minutos sem Wi-Fi ou 4G.", gerarDataFuturaAleatoria()),
                criarTarefa(5, "Atualizado - Usar um despertador de verdade", "Acorde sem apertar o botão de soneca.", gerarDataFuturaAleatoria()),
                criarTarefa(6, "Atualizado - Olhar para um livro sem surtar", "Leia 5 páginas de um livro e resista à tentação de pegar o celular.", gerarDataFuturaAleatoria()),
                criarTarefa(7, "Atualizado - Fazer uma refeição sem foto", "Coma sem tirar foto da comida e aproveite o momento.", gerarDataFuturaAleatoria()),
                criarTarefa(8, "Atualizado - Falar com alguém pessoalmente", "Converse cara a cara sem usar emojis ou figurinhas.", gerarDataFuturaAleatoria()),
                criarTarefa(9, "Atualizado - Usar menos de 50 filtros", "Poste uma foto natural, sem edição extrema.", gerarDataFuturaAleatoria()),
                criarTarefa(10, "Atualizado - Passar um dia sem falar 'cringe'", "Fique 24 horas sem usar a palavra 'cringe'.", gerarDataFuturaAleatoria())
        );
    }

    public static List<Object> getTarefasParaAtualizarInvalidas() {
        return List.of(
                criarTarefa(32, "Atualizado - Maratona de 30 segundos", "Agora assista 20 vídeos inteiros no TikTok sem rolar para cima.", gerarDataFuturaAleatoria()),
                criarTarefa(29, "Atualizado - Ler um texto de mais de 3 linhas", "Leia um artigo inteiro sem resumir apenas no título.", gerarDataFuturaAleatoria()),
                criarTarefa(38, "Atualizado - Responder mensagem no mesmo dia", "Responda as mensagens em menos de 1 hora.", gerarDataFuturaAleatoria()),
                criarTarefa(400, "Atualizado - Sobreviver sem Wi-Fi", "Agora tente 30 minutos sem Wi-Fi ou 4G.", gerarDataFuturaAleatoria()),
                criarTarefa(51, "Atualizado - Usar um despertador de verdade", "Acorde sem apertar o botão de soneca.", gerarDataFuturaAleatoria()),
                criarTarefa(62, "Atualizado - Olhar para um livro sem surtar", "Leia 5 páginas de um livro e resista à tentação de pegar o celular.", gerarDataFuturaAleatoria()),
                criarTarefa(73, "Atualizado - Fazer uma refeição sem foto", "Coma sem tirar foto da comida e aproveite o momento.", gerarDataFuturaAleatoria()),
                criarTarefa(81, "Atualizado - Falar com alguém pessoalmente", "Converse cara a cara sem usar emojis ou figurinhas.", gerarDataFuturaAleatoria()),
                criarTarefa(100, "Atualizado - Usar menos de 50 filtros", "Poste uma foto natural, sem edição extrema.", gerarDataFuturaAleatoria()),
                criarTarefa(97, "Atualizado - Passar um dia sem falar 'cringe'", "Fique 24 horas sem usar a palavra 'cringe'.", gerarDataFuturaAleatoria())
        );
    }



    public static Object criarTarefa(int id, String titulo, String descricao, String prazoStr) {
        try {
            Class<?> clazz = Class.forName("school.sptech.treino_prova.Tarefa");
            Constructor<?> constructor = clazz.getDeclaredConstructor();
            Object tarefa = constructor.newInstance();

            Method setId = clazz.getDeclaredMethod("setId", Integer.class);
            Method setTitulo = clazz.getDeclaredMethod("setTitulo", String.class);
            Method setDescricao = clazz.getDeclaredMethod("setDescricao", String.class);
            Method setPrazo = clazz.getDeclaredMethod("setPrazo", LocalDateTime.class);
            Method setFinalizada = clazz.getDeclaredMethod("setFinalizada", boolean.class);

            setId.invoke(tarefa, id);
            setTitulo.invoke(tarefa, titulo);
            setDescricao.invoke(tarefa, descricao);
            setPrazo.invoke(tarefa, LocalDateTime.parse(prazoStr));
            setFinalizada.invoke(tarefa, false);

            return tarefa;
        } catch (Exception e) {
            throw new RuntimeException("Erro ao criar objeto Tarefa via Reflection", e);
        }
    }

}