package school.sptech.treino_prova.cases;

import com.github.database.rider.core.api.dataset.DataSet;
import com.github.database.rider.core.api.dataset.ExpectedDataSet;
import com.github.database.rider.spring.api.DBRider;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.stream.Stream;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@DBRider
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@DisplayName("8. [Tarefa] Remoção")
public class TarefaRemocaoTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DataSet(value = "data/remocao/inicial-1.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/remocao/final-1.json", ignoreCols = {"prazo"})
    @DisplayName("8.1. Quando acionado com ID existente, deve remover e então retornar código HTTP correto")
    void quandoAcionadoComIdExistenteDeveRemoverETornarCodigoHttpCorreto() throws Exception {
        final var id = 2;
        mockMvc.perform(delete("/tarefas/" + id))
                .andExpect(status().isNoContent());
    }

    @ParameterizedTest
    @MethodSource("gerarIdsValidos")
    @DataSet(value = "data/remocao/inicial-2.json", cleanBefore = true, cleanAfter = true)
    @DisplayName("8.2. Quando acionado com ID existente, deve remover e então retornar código HTTP correto")
    void quandoAcionadoComIdInexistenteDeveRemoverETornarCodigoHttpCorreto(int id) throws Exception {
        mockMvc.perform(delete("/tarefas/" + id))
                .andExpect(status().isNoContent());
    }

    @ParameterizedTest
    @MethodSource("gerarIdsInvalidos")
    @DataSet(value = "data/remocao/inicial-2.json", cleanBefore = true, cleanAfter = true)
    @DisplayName("8.3. Quando acionado com ID inexistente, não deve remover e então retornar código HTTP correto")
    void quandoAcionadoComIdInexistenteNaoDeveRemoverETornarCodigoHttpCorreto(int id) throws Exception {
        mockMvc.perform(delete("/tarefas/" + id))
                .andExpect(status().isNotFound());
    }

    private static Stream<Integer> gerarIdsValidos() {
        return Stream.iterate(1, n -> n + 1).limit(24);
    }

    private static Stream<Integer> gerarIdsInvalidos() {
        return Stream.iterate(25, n -> n + 1).limit(42);
    }
}
