package school.sptech.treino_prova.fixture;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.List;

import static school.sptech.treino_prova.fixture.Util.gerarDataFuturaAleatoria;
import static school.sptech.treino_prova.fixture.Util.gerarDataPassadaAleatoria;


public class TarefaCadastroFixture {

    public static List<Object> getTarefasCadastroValidas() {
        return List.of(
                criarTarefa("Passar vergonha em redes sociais", "Grave um vídeo de alguma trend do TikTok e depois se arrependa.", gerarDataFuturaAleatoria()),
                criarTarefa("Fazer uma refeição sem foto", "Coma sem tirar foto da comida e aproveite o momento.", gerarDataFuturaAleatoria()),
                criarTarefa("Falar com alguém pessoalmente", "Converse cara a cara sem usar emojis ou figurinhas.", gerarDataFuturaAleatoria()),
                criarTarefa("Usar menos de 50 filtros", "Poste uma foto natural, sem edição extrema.", gerarDataFuturaAleatoria()),
                criarTarefa("Passar um dia sem falar 'cringe'", "Fique 24 horas sem usar a palavra 'cringe'.", gerarDataFuturaAleatoria()),
                criarTarefa("Criador de Gírias 2", "Invente uma gíria nova e convença pelo menos 3 pessoas a usá-la hoje.", gerarDataFuturaAleatoria()),
                criarTarefa("Fazer uma ligação", "Ligue para alguém e tenha uma conversa de pelo menos 5 minutos.", gerarDataFuturaAleatoria())
        );
    }

    public static List<Object> gerarTarefasCadastroInvalidas() {
        return List.of(
                criarTarefa("Criador de Gírias", "Invente uma gíria nova e convença pelo menos 3 pessoas a usá-la hoje.", gerarDataFuturaAleatoria()),
                criarTarefa("Gerador de figurinha", "Crie uma figurinha de cunho duvidoso e envie para um grupo de amigos.", gerarDataFuturaAleatoria()),
                criarTarefa("Deixando para depois", "Adie uma tarefa importante, faça outra coisa e depois se arrependa.", gerarDataFuturaAleatoria()));
    }

    public static List<Object> gerarTarefasCadastroInvalidasPorData() {
        return List.of(
                criarTarefa("Criador de Gírias 42", "Invente uma gíria nova e convença pelo menos 3 pessoas a usá-la hoje.", gerarDataPassadaAleatoria()),
                criarTarefa("Gerador de figurinha 42", "Crie uma figurinha de cunho duvidoso e envie para um grupo de amigos.", gerarDataPassadaAleatoria()),
                criarTarefa("Deixando para depois 42", "Adie uma tarefa importante, faça outra coisa e depois se arrependa.", gerarDataPassadaAleatoria()));
    }

    public static Object criarTarefa(String titulo, String descricao, String prazoStr) {
        try {
            Class<?> clazz = Class.forName("school.sptech.treino_prova.Tarefa");
            Constructor<?> constructor = clazz.getDeclaredConstructor();
            Object tarefa = constructor.newInstance();

            Method setTitulo = clazz.getDeclaredMethod("setTitulo", String.class);
            Method setDescricao = clazz.getDeclaredMethod("setDescricao", String.class);
            Method setPrazo = clazz.getDeclaredMethod("setPrazo", LocalDateTime.class);

            setTitulo.invoke(tarefa, titulo);
            setDescricao.invoke(tarefa, descricao);
            setPrazo.invoke(tarefa, LocalDateTime.parse(prazoStr));

            return tarefa;
        } catch (Exception e) {
            throw new RuntimeException("Erro ao criar objeto Tarefa via Reflection", e);
        }
    }
}
