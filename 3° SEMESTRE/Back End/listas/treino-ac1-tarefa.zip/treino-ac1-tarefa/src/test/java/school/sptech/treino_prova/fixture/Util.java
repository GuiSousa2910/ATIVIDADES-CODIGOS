package school.sptech.treino_prova.fixture;

import java.time.LocalDateTime;

public class Util {
    public static String gerarDataFuturaAleatoria() {
        String[] tiposIncremento = {"minutos", "horas", "dias", "meses", "anos"};
        String tipoIncremento = tiposIncremento[(int) (Math.random() * tiposIncremento.length)];
        int valorIncremento = 1 + (int) (Math.random() * 60);

        LocalDateTime dataHora = LocalDateTime.now();

        switch (tipoIncremento) {
            case "minutos":
                dataHora = dataHora.plusMinutes(valorIncremento);
                break;
            case "horas":
                dataHora = dataHora.plusHours(valorIncremento);
                break;
            case "dias":
                dataHora = dataHora.plusDays(valorIncremento);
                break;
            case "meses":
                dataHora = dataHora.plusMonths(valorIncremento);
                break;
            case "anos":
                dataHora = dataHora.plusYears(valorIncremento);
                break;
        }

        return dataHora.toString();
    }

    public static String gerarDataPassadaAleatoria() {
        String[] tiposIncremento = {"minutos", "horas", "dias", "meses", "anos"};
        String tipoIncremento = tiposIncremento[(int) (Math.random() * tiposIncremento.length)];
        int valorIncremento = 1 + (int) (Math.random() * 60);

        LocalDateTime dataHora = LocalDateTime.now();

        switch (tipoIncremento) {
            case "minutos":
                dataHora = dataHora.minusMinutes(valorIncremento);
                break;
            case "horas":
                dataHora = dataHora.minusHours(valorIncremento);
                break;
            case "dias":
                dataHora = dataHora.minusDays(valorIncremento);
                break;
            case "meses":
                dataHora = dataHora.minusMonths(valorIncremento);
                break;
            case "anos":
                dataHora = dataHora.minusYears(valorIncremento);
                break;
        }

        return dataHora.toString();
    }
}
