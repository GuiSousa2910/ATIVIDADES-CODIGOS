package school.sptech.treino_prova.cases;

import com.github.database.rider.core.api.dataset.DataSet;
import com.github.database.rider.core.api.dataset.ExpectedDataSet;
import com.github.database.rider.spring.api.DBRider;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.stream.IntStream;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@DBRider
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@DisplayName("3. [Tarefa] Buscar por ID")
public class TarefaPorIdTests {

    @Autowired
    private MockMvc mockMvc;

    @ParameterizedTest
    @MethodSource("gerarIdsValidos")
    @DataSet(value = "data/id/inicial.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/id/inicial.json", ignoreCols = {"prazo"})
    @DisplayName("3.1. Quando acionado com ID existente, então deve retornar tarefa e o código HTTP correto")
    void quandoAcionadoComIdExistenteEntaoRetornarTarefaComCodigoHttpCorreto(int id) throws Exception {
        mockMvc.perform(get("/tarefas/" + id))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.titulo").exists())
                .andExpect(jsonPath("$.descricao").exists())
                .andExpect(jsonPath("$.status").exists())
                .andExpect(jsonPath("$.prazo").exists());

    }

    @ParameterizedTest
    @MethodSource("gerarIdsInvalidos")
    @DataSet(value = "data/id/inicial.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/id/inicial.json", ignoreCols = {"prazo"})
    @DisplayName("3.2. Quando acionado com ID inexistente, então deve retornar código HTTP correto")
    void quandoAcionadoComIdInexistenteEntaoRetornarCodigoHttpCorreto() throws Exception {
        final var id = 26;
        mockMvc.perform(get("/tarefas/" + id))
                .andExpect(status().isNotFound());
    }

    static List<Integer> gerarIdsValidos() {
        final var initial = 1;
        final var finalValue = 25;
        return IntStream.rangeClosed(initial, finalValue).boxed().toList();
    }

    static List<Integer> gerarIdsInvalidos() {
        final var initial = 26;
        final var finalValue = 42;
        return IntStream.rangeClosed(initial, finalValue).boxed().toList();
    }
}
