package school.sptech.treino_prova.cases;

import com.github.database.rider.core.api.dataset.DataSet;
import com.github.database.rider.spring.api.DBRider;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@DBRider
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@DisplayName("7. [Tarefa] Período")
public class TarefaPeriodoTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DataSet(value = "data/periodo/inicial.json", cleanBefore = true, cleanAfter = true)
    @DisplayName("7.1. Quando acionado com periodo válido, então deve retornar tarefas que estão no período informado e código HTTP correto")
    void quandoAcionadoEntaoRetornarTarefasDoPeriodoEStatusAdequado() throws Exception {
        mockMvc.perform(get("/tarefas/periodo?inicio=2022-03-10T13:30:00&fim=2025-01-13T10:00:00"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));
    }

    @Test
    @DataSet(value = "data/periodo/inicial.json", cleanBefore = true, cleanAfter = true)
    @DisplayName("7.2. Quando acionado e não houver tarefas no período, então deve retornar código HTTP correto")
    void quandoAcionadoENaoHouverTarefasNoPeriodoEntaoRetornarStatusAdequado() throws Exception {
        mockMvc.perform(get("/tarefas/periodo?inicio=2025-03-10T13:30:00&fim=2025-01-19T10:00:00"))
                .andExpect(status().isNoContent());
    }
}
