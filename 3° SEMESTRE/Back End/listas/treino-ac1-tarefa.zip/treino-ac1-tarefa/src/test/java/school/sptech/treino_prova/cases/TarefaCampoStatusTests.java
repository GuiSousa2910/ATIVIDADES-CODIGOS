package school.sptech.treino_prova.cases;

import com.github.database.rider.core.api.dataset.DataSet;
import com.github.database.rider.core.api.dataset.ExpectedDataSet;
import com.github.database.rider.spring.api.DBRider;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@DBRider
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@DisplayName("4. [Tarefa] Campo status (Depende do passo 3)")
public class TarefaCampoStatusTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DataSet(value = "data/status/em-dia.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/status/em-dia.json", ignoreCols = {"id", "prazo"})
    @DisplayName("4.1. Quando tarefa estiver em dia, então deve retornar status EM_DIA")
    void quandoTarefaEstiverEmDiaEntaoRetornarStatusEmDia() throws Exception {

        final var statusEsperado = "EM_DIA";

        mockMvc.perform(get("/tarefas/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(statusEsperado));
    }

    @Test
    @DataSet(value = "data/status/atrasada.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/status/atrasada.json", ignoreCols = {"id", "prazo"})
    @DisplayName("4.2. Quando tarefa estiver atrasada, então deve retornar status ATRASADA")
    void quandoTarefaEstiverAtrasadaEntaoRetornarStatusAtrasada() throws Exception {

        final var statusEsperado = "ATRASADA";

        mockMvc.perform(get("/tarefas/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(statusEsperado));
    }

    @Test
    @DataSet(value = "data/status/finalizada.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/status/finalizada.json", ignoreCols = {"id", "prazo"})
    @DisplayName("4.2. Quando tarefa estiver atrasada, então deve retornar status FINALZADA")
    void quandoTarefaEstiverFinalizadaEntaoRetornarStatusFinalizada() throws Exception {

        final var statusEsperado = "FINALIZADA";

        mockMvc.perform(get("/tarefas/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(statusEsperado));
    }
}
