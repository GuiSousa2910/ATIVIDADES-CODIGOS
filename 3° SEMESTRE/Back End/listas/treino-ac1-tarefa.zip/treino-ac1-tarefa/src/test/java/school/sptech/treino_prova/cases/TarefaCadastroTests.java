package school.sptech.treino_prova.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.database.rider.core.api.dataset.DataSet;
import com.github.database.rider.core.api.dataset.ExpectedDataSet;
import com.github.database.rider.spring.api.DBRider;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import school.sptech.treino_prova.Tarefa;
import school.sptech.treino_prova.fixture.TarefaCadastroFixture;

import java.time.LocalDateTime;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@DBRider
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@DisplayName("1. [Tarefa] Cadastro")
public class TarefaCadastroTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @DataSet(value = "data/cadastro/inicial.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/cadastro/sucesso.json", ignoreCols = {"id", "prazo"})
    @DisplayName("1.1 Quando cadastrar tarefa com sucesso, deve retornar a tarefa e o código status HTTP adequado [ ÚNICO - DB ]")
    void quandoCadastrarTarefaComSucessoEntaoRetornarStatusAdequado() throws Exception {

        final var titulo = "Passar vergonha em redes sociais";
        final var descricao = "Grave um vídeo de alguma trend do TikTok e depois se arrependa.";
        final var prazo = LocalDateTime.now().plusDays(1).toString();

        Object tarefa = TarefaCadastroFixture.criarTarefa
                (titulo, descricao, prazo);

        mockMvc.perform(post("/tarefas")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.titulo").value(titulo))
                .andExpect(jsonPath("$.descricao").value(descricao));
    }

    @Test
    @DataSet(value = "data/cadastro/inicial.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/cadastro/inicial.json", ignoreCols = {"id", "prazo"})
    @DisplayName("1.2 Quando tentar cadastrar tarefa com título já existente, deve impedir e então retornar status HTTP adequado")
    void quandoCadastrarTarefaComTituloJaExistenteEntaoRetornarStatusAdequado() throws Exception {

        Object tarefa = TarefaCadastroFixture.criarTarefa(
                "Criador de Gírias",
                "Invente uma gíria nova e convença pelo menos 3 pessoas a usá-la hoje.",
                LocalDateTime.now().plusDays(1).toString()
        );

        mockMvc.perform(post("/tarefas")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isConflict());
    }

    @ParameterizedTest
    @MethodSource("school.sptech.treino_prova.fixture.TarefaCadastroFixture#getTarefasCadastroValidas")
    @DisplayName("1.3 Quando cadastrar tarefa com sucesso, deve retornar a tarefa e o código status HTTP adequado [ LOTE ]")
    void quandoCadastrarTarefaComSucessoEntaoRetornarStatusAdequado(Tarefa tarefa) throws Exception {
        mockMvc.perform(post("/tarefas")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.titulo").value(tarefa.getTitulo()))
                .andExpect(jsonPath("$.descricao").value(tarefa.getDescricao()));
    }

    @ParameterizedTest
    @DataSet(value = "data/cadastro/inicial.json", cleanBefore = true, cleanAfter = true)
    @MethodSource("school.sptech.treino_prova.fixture.TarefaCadastroFixture#gerarTarefasCadastroInvalidas")
    @DisplayName("1.4 Quando tentar cadastrar tarefa inválida por titulo já existente, deve impedir e então retornar status HTTP adequado [ LOTE ]")
    void quandoCadastrarTarefaInvalidaEntaoRetornarStatusAdequado(Tarefa tarefa) throws Exception {
        mockMvc.perform(post("/tarefas")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isConflict());
    }

    @Test
    @DataSet(value = "data/cadastro/inicial.json", cleanBefore = true, cleanAfter = true)
    @ExpectedDataSet(value = "data/cadastro/inicial.json", ignoreCols = {"id", "prazo"})
    @DisplayName("1.5 Quando tentar cadastrar tarefa com título já existente (case insensitive), deve impedir e então retornar status HTTP adequado")
    void quandoCadastrarTarefaComTituloJaExistenteCaseInsensitiveEntaoRetornarStatusAdequado() throws Exception {

        Object tarefa = TarefaCadastroFixture.criarTarefa(
                "cRiador de GíriAs",
                "Invente uma gíria nova e convença pelo menos 3 pessoas a usá-la hoje.",
                "2025-03-26T20:00:00"
        );

        mockMvc.perform(post("/tarefas")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isConflict());
    }

    @ParameterizedTest
    @DataSet(value = "data/cadastro/inicial.json", cleanBefore = true, cleanAfter = true)
    @MethodSource("school.sptech.treino_prova.fixture.TarefaCadastroFixture#gerarTarefasCadastroInvalidasPorData")
    @DisplayName("1.4 Quando tentar cadastrar tarefa com data anterior a data atual, deve impedir e então retornar status HTTP adequado [ LOTE ]")
    void quandoCadastrarTarefaInvalidaPorDataEntaoRetornarStatusAdequado(Tarefa tarefa) throws Exception {
        mockMvc.perform(post("/tarefas")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(tarefa)))
                .andExpect(status().isBadRequest());
    }
}