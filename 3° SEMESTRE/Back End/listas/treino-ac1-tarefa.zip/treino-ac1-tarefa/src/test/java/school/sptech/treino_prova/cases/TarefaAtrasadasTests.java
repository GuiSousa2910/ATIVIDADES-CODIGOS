package school.sptech.treino_prova.cases;

import com.github.database.rider.core.api.dataset.DataSet;
import com.github.database.rider.spring.api.DBRider;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@DBRider
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@DisplayName("6. [Tarefa] Atrasadas")
public class TarefaAtrasadasTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DataSet(value = "data/atrasadas/inicial.json", cleanBefore = true, cleanAfter = true)
    @DisplayName("6.1. Quando acionado, então deve retornar tarefas atrasadas e status HTTP correto")
    void quandoAcionadoEntaoRetornarTarefasAtrasadasEStatusAdequado() throws Exception {

        final var statusEsperado = "ATRASADA";

        mockMvc.perform(get("/tarefas/atrasadas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(3))
                .andExpect(jsonPath("$[0].status").value(statusEsperado))
                .andExpect(jsonPath("$[1].status").value(statusEsperado))
                .andExpect(jsonPath("$[2].status").value(statusEsperado));
    }

    @Test
    @DataSet(value = "data/atrasadas/sem-atraso.json", cleanBefore = true, cleanAfter = true)
    @DisplayName("6.2. Quando acinonado e não houver tarefas atrasadas, então deve retornar status HTTP correto")
    void quandoAcionadoENaoHouverTarefasAtrasadasEntaoRetornarStatusAdequado() throws Exception {
        mockMvc.perform(get("/tarefas/atrasadas"))
                .andExpect(status().isNoContent());
    }
}
